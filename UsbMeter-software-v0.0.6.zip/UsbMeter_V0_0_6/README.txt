This application uses LGPLv3 QT, including core, gui, and multimedia components.


Please select the corresponding version according to whether the windows is x64 or x86.

